import React from 'react';

const Logo = (props) => {
    return (
        <div className='logo'>
            World Data Mapper
        </div>
    );
};

export default Logo;