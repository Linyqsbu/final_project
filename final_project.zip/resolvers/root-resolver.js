const userResolvers = require('./user-resolver');
const mapResolvers = require('./map-resolver');

module.exports = [userResolvers, mapResolvers];